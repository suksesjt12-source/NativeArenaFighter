# Build APK using only an Android phone (cloud build)

This project includes a GitHub Actions workflow that builds the debug APK in the cloud. No computer or local Android SDK is required, but a GitHub account and internet access are required.

1. On your phone, sign in to GitHub in a browser and create a **new public repository** (for example `NativeArenaFighter`).
2. Extract this ZIP on your phone using a file manager that can extract ZIP files.
3. Upload the *contents* of the `NativeArenaFighter` folder to the repository, including the hidden `.github/workflows/build-apk.yml` file. If your phone's file picker hides `.github`, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow contents from this file.
4. Open the repository's **Actions** tab and select **Build Android APK**. If prompted, enable workflows. Tap **Run workflow**.
5. Wait for the run to finish successfully. Open that run and scroll to **Artifacts**.
6. Download `NativeArenaFighter-debug-apk`, extract the downloaded artifact ZIP, then tap `app-debug.apk` to install it. Android may ask you to allow installation from that browser/file manager.

The result is a debug APK of the starter prototype, not a native port of the original Naruto game. It contains placeholder fighters and original simple gameplay only.

# Native Arena Fighter — Android starter prototype

This is a **native Android source project** (Java + Android Canvas; no emulator and no game engine dependency). It is a playable starter: landscape arena, two placeholder fighters, health bars, movement, jump, quick attack and special attack.

## Important scope note
This is **not** a port of *Naruto Shippuden: Ultimate Ninja Storm 3 Full Burst*. The original game is proprietary, and a real native port cannot be produced by renaming or converting a Nintendo Switch game file. It needs authorized source code/game assets or a substantial clean-room reimplementation. This project deliberately uses simple original placeholder visuals and does not include Naruto character art, game files, console firmware, keys, or copyrighted audio.

## Open and build
1. Install Android Studio on a computer and allow it to install Android SDK Platform 35 and a compatible Android Gradle Plugin.
2. Open the extracted `NativeArenaFighter` folder in Android Studio.
3. Wait for Gradle sync, then choose **Build > Build APK(s)**.
4. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.
5. Install that APK on an Android device for testing.

This environment did not have an Android SDK/build toolchain installed, so the ZIP contains buildable project source, not a precompiled APK.

## Controls
- Bottom-left: move left/right (hold).
- JUMP: jump.
- HIT: quick attack (short range).
- JUTSU: special attack (longer range, bigger damage).
- After a match ends, tap anywhere to restart.

## Next engineering steps for a legitimate native adaptation
- Confirm rights and obtain legally usable assets/source.
- Select a 3D engine/rendering stack and define the asset pipeline.
- Recreate animation state machines, camera, collision/hitboxes, particle effects, AI, menus, audio, save/load, and controller/touch input.
- Profile GPU/CPU/memory on the target phone, then optimize shaders, texture sizes, draw calls and animation budgets.

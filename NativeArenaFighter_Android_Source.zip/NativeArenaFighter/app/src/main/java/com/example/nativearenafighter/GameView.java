package com.example.nativearenafighter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

/** Small, fully native Android Canvas prototype. All visuals are original placeholders. */
public class GameView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random(7);
    private long lastFrame = System.nanoTime();
    private float worldW = 1000, worldH = 600;
    private float playerX = 330, enemyX = 700;
    private float playerY = 420, enemyY = 420;
    private float playerHp = 100, enemyHp = 100;
    private float playerVy = 0, enemyVy = 0;
    private float attackFlash = 0, jutsuFlash = 0;
    private float enemyThink = 0;
    private boolean left, right;
    private String message = "READY  •  FIGHT!";
    private float messageTimer = 2.0f;
    private boolean ended = false;

    public GameView(Context context) { super(context); setFocusable(true); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() == 0 || getHeight() == 0) return;
        float sx = getWidth() / worldW, sy = getHeight() / worldH;
        canvas.save(); canvas.scale(sx, sy);
        long now = System.nanoTime();
        float dt = Math.min(0.04f, (now - lastFrame) / 1_000_000_000f); lastFrame = now;
        update(dt);
        drawBackground(canvas);
        drawArena(canvas);
        drawHud(canvas);
        drawFighter(canvas, playerX, playerY, true, attackFlash > 0 || jutsuFlash > 0);
        drawFighter(canvas, enemyX, enemyY, false, false);
        drawEffects(canvas);
        drawControls(canvas);
        if (ended) drawEnd(canvas);
        canvas.restore();
        postInvalidateOnAnimation();
    }

    private void update(float dt) {
        if (ended) return;
        if (left) playerX -= 260 * dt;
        if (right) playerX += 260 * dt;
        playerX = clamp(playerX, 95, 905);
        playerVy += 900 * dt; playerY += playerVy * dt;
        if (playerY > 420) { playerY = 420; playerVy = 0; }
        enemyVy += 900 * dt; enemyY += enemyVy * dt;
        if (enemyY > 420) { enemyY = 420; enemyVy = 0; }
        enemyThink += dt;
        if (enemyThink > 1.3f) {
            enemyThink = 0;
            if (Math.abs(enemyX - playerX) > 145) enemyX += Math.signum(playerX - enemyX) * 35;
            else if (random.nextFloat() > .32f) { playerHp = Math.max(0, playerHp - 4); message = "GUARD OR MOVE!"; messageTimer = .55f; }
            enemyX = clamp(enemyX, 95, 905);
        }
        attackFlash = Math.max(0, attackFlash - dt);
        jutsuFlash = Math.max(0, jutsuFlash - dt);
        messageTimer = Math.max(0, messageTimer - dt);
        if (playerHp <= 0 || enemyHp <= 0) { ended = true; message = enemyHp <= 0 ? "YOU WIN!" : "TRY AGAIN"; }
    }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0, 0, 0, worldH, Color.rgb(8, 15, 39), Color.rgb(37, 37, 74), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, worldW, worldH, p); p.setShader(null);
        // Original abstract skyline and moon
        p.setColor(Color.argb(70, 73, 124, 191)); c.drawCircle(800, 112, 58, p);
        p.setColor(Color.argb(90, 151, 198, 255)); c.drawCircle(800, 112, 42, p);
        for (int i=0;i<15;i++) {
            float x = i*74 - 6, h = 70 + (i*47%105);
            p.setColor(i%2==0 ? Color.rgb(20,30,58) : Color.rgb(26,35,68));
            c.drawRect(x, 365-h, x+58, 370, p);
            p.setColor(Color.argb(90, 64, 182, 235));
            for (int j=0;j<4;j++) c.drawRect(x+8+j*12, 380-h, x+12+j*12, 370, p);
        }
        p.setShader(new LinearGradient(0, 370, 0, 600, Color.rgb(32,48,78), Color.rgb(8,15,30), Shader.TileMode.CLAMP));
        c.drawRect(0, 370, 1000, 600, p); p.setShader(null);
    }

    private void drawArena(Canvas c) {
        p.setColor(Color.argb(70, 61, 206, 255)); p.setStrokeWidth(2);
        for (int i=0;i<11;i++) { float y=450+i*i*1.18f; c.drawLine(0,y,1000,y,p); }
        for (int i=0;i<=12;i++) { float x=i*100; c.drawLine(500,430,x,600,p); }
        p.setColor(Color.argb(100, 69, 216, 255)); p.setStrokeWidth(3); c.drawLine(0,438,1000,438,p);
        p.setColor(Color.argb(45, 0, 0, 0)); c.drawOval(playerX-47, 423, playerX+47, 444, p); c.drawOval(enemyX-47, 423, enemyX+47, 444,p);
    }

    private void drawHud(Canvas c) {
        p.setColor(Color.argb(220, 7, 11, 25)); c.drawRoundRect(22, 20, 978, 100, 18,18,p);
        drawBar(c, 42, 39, 395, 20, playerHp, Color.rgb(50,225,255));
        drawBar(c, 563, 39, 395, 20, enemyHp, Color.rgb(255,77,101));
        text(c, "PLAYER", 42, 31, 16, Color.WHITE, Paint.Align.LEFT, true);
        text(c, "CPU RIVAL", 958, 31, 16, Color.WHITE, Paint.Align.RIGHT, true);
        p.setColor(Color.rgb(251, 200, 90)); c.drawRoundRect(456, 43,544, 77, 9,9,p);
        text(c,"VS",500,66,19,Color.rgb(20,20,35),Paint.Align.CENTER,true);
        text(c, messageTimer > 0 ? message : "NATIVE ARENA PROTOTYPE", 500, 125, 18, Color.WHITE, Paint.Align.CENTER, true);
    }
    private void drawBar(Canvas c, float x, float y, float w, float h, float hp, int color) {
        p.setColor(Color.rgb(35,42,60)); c.drawRoundRect(x,y,x+w,y+h,8,8,p);
        p.setColor(color); c.drawRoundRect(x,y,x+w*Math.max(0,hp)/100f,y+h,8,8,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.argb(180,220,240,255)); c.drawRoundRect(x,y,x+w,y+h,8,8,p); p.setStyle(Paint.Style.FILL);
    }

    private void drawFighter(Canvas c, float x, float baseY, boolean player, boolean powered) {
        c.save(); c.translate(x, baseY);
        int main = player ? Color.rgb(35,190,230) : Color.rgb(235,70,93);
        int dark = player ? Color.rgb(16,55,92) : Color.rgb(92,27,50);
        if (!player) c.scale(-1,1);
        if (powered) { p.setColor(Color.argb(65, main, main, main)); c.drawCircle(0,-85,72,p); p.setColor(Color.argb(70, main>>16&255, main>>8&255, main&255)); c.drawCircle(0,-85,52,p); }
        // scarf / headband tails
        p.setColor(dark); Path scarf = new Path(); scarf.moveTo(-10,-112); scarf.lineTo(-55,-103); scarf.lineTo(-72,-116); scarf.lineTo(-50,-91); scarf.lineTo(-13,-98); scarf.close(); c.drawPath(scarf,p);
        // legs
        p.setColor(dark); c.drawRoundRect(-25,-43,-4,-5,8,8,p); c.drawRoundRect(4,-43,25,-5,8,8,p);
        p.setColor(Color.rgb(8,13,24)); c.drawRoundRect(-31,-10,-2,-2,5,5,p); c.drawRoundRect(2,-10,31,-2,5,5,p);
        // torso and arms
        p.setColor(main); c.drawRoundRect(-29,-99,29,-38,13,13,p);
        p.setColor(dark); c.drawRoundRect(-45,-91,-26,-53,8,8,p); c.drawRoundRect(25,-91,44,-53,8,8,p);
        p.setColor(main); c.drawCircle(-35,-52,11,p); c.drawCircle(35,-52,11,p);
        // face/head & mask
        p.setColor(Color.rgb(230,190,160)); c.drawOval(-22,-139,22,-96,p);
        p.setColor(dark); c.drawRoundRect(-26,-140,26,-128,5,5,p);
        p.setColor(Color.WHITE); c.drawCircle(-9,-118,3,p); c.drawCircle(9,-118,3,p);
        p.setColor(Color.rgb(24,25,42)); c.drawCircle(-9,-118,1.5f,p); c.drawCircle(9,-118,1.5f,p);
        p.setColor(dark); c.drawRect(-18,-106,18,-100,p);
        // small shoulder guard
        p.setColor(Color.argb(220,245,245,255)); c.drawCircle(27,-87,5,p);
        c.restore();
    }

    private void drawEffects(Canvas c) {
        if (attackFlash > 0) {
            float t = attackFlash / .25f;
            p.setColor(Color.argb((int)(220*t), 255, 236, 116)); p.setStrokeWidth(8);
            c.drawLine(playerX+35, playerY-75, playerX+125, playerY-110, p);
            p.setStrokeWidth(2); c.drawCircle(enemyX, enemyY-80, 35*(1-t)+8, p);
        }
        if (jutsuFlash > 0) {
            float t = jutsuFlash / .75f;
            p.setColor(Color.argb((int)(160*t), 50, 205, 255)); c.drawCircle(playerX+55, playerY-78, 110*(1-t)+35, p);
            p.setColor(Color.argb((int)(220*t), 225, 250, 255)); c.drawCircle(playerX+55, playerY-78, 46*(1-t)+8, p);
        }
    }

    private void drawControls(Canvas c) {
        button(c, 72, 512, 68, 68, "◀", Color.rgb(27,72,112));
        button(c, 153, 512, 68, 68, "▶", Color.rgb(27,72,112));
        button(c, 748, 512, 76, 68, "JUMP", Color.rgb(49,81,122));
        button(c, 834, 512, 76, 68, "HIT", Color.rgb(141,55,68));
        button(c, 920, 512, 68, 68, "JUTSU", Color.rgb(39,130,165));
        text(c,"MOVE",146,488,13,Color.argb(210,220,235,255),Paint.Align.CENTER,true);
        text(c,"ACTIONS",867,488,13,Color.argb(210,220,235,255),Paint.Align.CENTER,true);
    }
    private void button(Canvas c, float x, float y, float w, float h, String label, int fill) {
        p.setColor(Color.argb(155,6,10,22)); c.drawRoundRect(x+3,y+5,x+w+3,y+h+5,16,16,p);
        p.setColor(fill); c.drawRoundRect(x,y,x+w,y+h,16,16,p);
        p.setColor(Color.argb(200,225,245,255)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); c.drawRoundRect(x,y,x+w,y+h,16,16,p); p.setStyle(Paint.Style.FILL);
        text(c,label,x+w/2,y+h/2+6,label.length()>4?13:24,Color.WHITE,Paint.Align.CENTER,true);
    }
    private void drawEnd(Canvas c) {
        p.setColor(Color.argb(190,2,5,15)); c.drawRect(0,0,1000,600,p);
        text(c, enemyHp<=0?"VICTORY":"DEFEAT",500,260,48,Color.WHITE,Paint.Align.CENTER,true);
        text(c,"Tap anywhere to restart",500,315,22,Color.rgb(112,224,255),Paint.Align.CENTER,false);
    }
    private void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align align, boolean bold) {
        p.setShader(null); p.setColor(color); p.setTextSize(size); p.setTextAlign(align); p.setTypeface(bold?android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD):android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL)); c.drawText(s,x,y,p);
    }
    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX() * worldW / Math.max(1,getWidth());
        float y = e.getY() * worldH / Math.max(1,getHeight());
        if (ended) { if(e.getAction()==MotionEvent.ACTION_DOWN){playerHp=100;enemyHp=100;playerX=330;enemyX=700;ended=false;message="READY  •  FIGHT!";messageTimer=1.5f;} return true; }
        if (e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) {left=false;right=false;return true;}
        if (e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
            left = x<145 && y>475; right = x>=145 && x<230 && y>475;
            if (e.getAction()==MotionEvent.ACTION_DOWN && y>490) {
                if(x>=740 && x<830) { if(playerY>=420) playerVy=-470; }
                else if(x>=830 && x<915) { attackFlash=.25f; if(Math.abs(enemyX-playerX)<190) enemyHp=Math.max(0,enemyHp-10); message="QUICK ATTACK!";messageTimer=.6f; }
                else if(x>=915) { jutsuFlash=.75f; if(Math.abs(enemyX-playerX)<360) enemyHp=Math.max(0,enemyHp-22); message="SPECIAL TECHNIQUE!";messageTimer=.8f; }
            }
            return true;
        }
        return true;
    }
}
